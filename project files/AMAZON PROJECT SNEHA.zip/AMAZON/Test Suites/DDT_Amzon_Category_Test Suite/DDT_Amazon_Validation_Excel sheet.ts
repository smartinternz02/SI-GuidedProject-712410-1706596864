<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DDT_Amazon_Validation_Excel sheet</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>b723610d-700f-45e6-afda-8dada91b981d</testSuiteGuid>
   <testCaseLink>
      <guid>a2ecd8ec-35b5-4262-beaf-c79910180272</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Amazon_Validation/TC_Amazon_DDT/TC_Amazon_Search_DDT_Excel</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>620a7cd1-820f-49a0-9f5c-9f0d5c93de90</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_Test Data/Amzon_Test Data_Excel_Category</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>620a7cd1-820f-49a0-9f5c-9f0d5c93de90</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>CategoryItem</value>
         <variableId>35d353b6-c776-412a-8461-70d7cc11069a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>620a7cd1-820f-49a0-9f5c-9f0d5c93de90</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Items</value>
         <variableId>3e8534fa-b2ab-44bb-92d2-3a7d2db10482</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
